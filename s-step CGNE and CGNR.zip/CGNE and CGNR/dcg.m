function [x,resnorm]=dcg()
warning('off');
clc
clear r;
A=mmread('pde225.mtx');
n=size(A,1);
I=eye(n,n);
A1=(A+A');
x=rand(n,1);
x1=ones(n,1);
b=A*x1;
K=100;
%%%%%%%%%%%                                                                   
eps=1.e-15;
r=b-A*x;                                                    
p=r;                                                               
rsold=r'*r;    
rnorm=sqrt(rsold);
ro=zeros(K,1);                         
ro(1)=rnorm;  
alpha=1;
beta=1;
tic
for i=1:K-1     
    mo=beta^i;
    A=A1+mo*I;
   Ap=A*p;                                                      
   alpha=rsold/(p'*Ap);                                                                  
   x=x+alpha*p;                                               
   r=r-alpha*Ap;    
   rsnew=r'*r; 
   rnorm=sqrt(rsnew);    
%    b=b+A'*x+mo*x;
         ro(i+1)=norm(x1-x);                                              
   if   ( rnorm<eps )                             
       break                                                          
   end                                                                   
beta=rsnew/rsold;
   p=r+beta*p;                                
rsold = rsnew;                                      
end   
toc
h=1:K;                                            
ro=log10(ro);                                                       
plot(h,ro,'g-o')                                                           
 legend('CG21')  
hold on                                                               
end                                                                       
