function [x,resnorm]= cgne()
warning('off');
clc
clear r;
%%%%%%%%%%%%%
n=10;
m=10;
b=zeros(n+1,1);
% A=zeros(n,m);
t=0:n;
t=t'/(2*n);
u=(2*t).*(1-2*t);
g=zeros(m,n+1);
for i=1:n+1
    for j=1:m
        g(i,j)=(1-2*pi*(5*t(i)-1))^(-pi^2*(5*t(i)-1)^2);%(t(i)-2*s1(j));
    end
end
    for j=1:n+1
        A(:,j)=sin((j-1).*t);
    end
    b=A*u;
    x=zeros(n+1,1);
    K=100;
%%%%%%%%%%%%%
% A=mmread('nos4.mtx');
% % A=[1.2 0.213 -0.333 1;1 1 0 1;1 0 1 0;1.1 -0.5 0.9 -0.8];
% n=size(A,2);
% x=zeros(n,1);
% x1=ones(n,1);
% for i=1:n
% %     x1(i)=(i/n)*sin(i^2/(n));
% x1(i)=exp(-10*(i-n/2)^2/n)-exp(-10*(i-(n/2+3))^2/n);
% end
% b=A*x1;
% K=max(size(A));
%%%%%%
% n=size(A,1);
% v=1:n;
% v=v';
% % u=exp(-(n/2-v).^2);
% u=v.*sin(v)/n;
% b=A*u;
%%%%%%%%%%%%%%%%%%%%%%
% M=diag(1./diag(A));%ichol(A);%
% % M=inv(M'*M);
% A=M*A;
% b=M*b;
% K=4*length(b);
%%%%%%%%%%%%%%%%%%%%%%%
r=b-A*x;
z=A'*r;
P=z;
resnorm=zeros(1,K);
resnorm(1)=norm(r);
k=1;
tic
while(k<=K)
     W=A*P;
    alfa=(P'*P)\(r'*r);
    x=x+P*alfa;
    r=r-W*alfa;
    resnorm(k+1)=norm(r);
    z=A'*r;
     beta=(resnorm(k+1))/(resnorm(k));
    P=z+P*beta;
    k=k+1;
      %%%%%%%%%%%%%
%     lambda=1;
% E=0.00001*(x*b');
% d=1/k;
% w=r;
% A=lambda*A+E*(w*w');
% b=lambda*b+E*(d*w);
    %%%%%%%%%%%%%
      %%%%%%%%%noise%%%
%       A=A+0.0001*x1*b';%randn(size(A));
%     b=b+0.0001*x1;%randn(size(b));
    %%%%%%%%%%%%%%
end
toc
S=1:length(resnorm);
resnorm=log10(resnorm);
plot(S,resnorm,'rx-');
xlabel('iteration')
ylabel('log(||r||)')
%%%%%%%%%%%%%%%%%%%
% v=1:length(u);
% plot(t,x,'rx-');
% legend('Exact','CGNR');
% xlabel('i')
% ylabel('u(i)')
 hold on
 end
