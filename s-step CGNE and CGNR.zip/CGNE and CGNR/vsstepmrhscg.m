function [X,resnorm]= vsstepmrhscg(A,B,X,K)
warning('off');
clc
clear R;
M=diag(1./diag(A));%ichol(A);%
% M=inv(M'*M);
A=M*A;
B=M*B;
t=size(X,2);
R=B-A*X;
resnorm=zeros(1,K);
s=1;
k=1;
S=zeros(1,K);
S(1)=1;
P(:,1:t)=R;
tic
for i=1:s-1
    P(:,i*t+1:(i+1)*t)=A*P(:,(i-1)*t+1:i*t);
end
%       for j2=1:size(P,2)
%         for i2=1:j2
%            P(:,j2)=P(:,j2)-(P(:,i2)'*P(:,j2))*P(:,i2);
%         end
%            P(:,j2)=P(:,j2)/norm(P(:,j2));
%       end
while(S(k)<K)
    alfa=(P'*A*P)\(P'*R);
    for i=1:size(alfa,2)
    s1=floor(1/(norm(alfa(:,i))));
    s=max(s1,s);
    end
    alfa=(P'*(A+(1/(s^2+s))*eye(size(A)))*P)\(P'*R);
    X=X+P*alfa;
    R=R-A*P*alfa;
    W=zeros(size(A,1),s*t);
    W(:,1:t)=R;
    for i=1:s-1
    W(:,i*t+1:(i+1)*t)=A*W(:,(i-1)*t+1:i*t);
    end
%       for j2=1:size(W,2)
%         for i2=1:j2
%            W(:,j2)=W(:,j2)-(W(:,i2)'*W(:,j2))*W(:,i2);
%         end
%            W(:,j2)=W(:,j2)/norm(W(:,j2));
%       end
    beta=(P'*A*P)\(P'*A*W);
    P=W+P*beta;
    resnorm(k)=norm(R);
    S(k+1)=S(k)+s;
    k=k+1;
end
toc
%  N=1:K;
 jndex=1;
 for j=1:K
     if S(j)==0
         jndex=j;
         break
     end
 end
 jndex=jndex-1;
 S=S(1:end-jndex);
 resnorm=resnorm(1:end-jndex);
%  S1=size(S);
%  S=1:S1(2);
%  S=S*(K/S1(2));
resnorm=log(resnorm);
plot(S,resnorm,'*-');
% legend('CG','vs-step CG');
legend('CG','s-CG','reg s-CG');
xlim([0,K]);
xlabel('iteration')
ylabel('log(||r||)')
 hold on
 end
