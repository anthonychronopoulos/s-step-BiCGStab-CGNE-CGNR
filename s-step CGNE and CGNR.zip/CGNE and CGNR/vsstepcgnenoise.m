function [x,resnorm]= vsstepcgnenoise(A,b,x)
warning('off');
clc
clear r;
%%%%%%
n=size(A,1);
v=1:n;
v=v';
% u=exp(-(n/2-v).^2);
u=(v).*sin(v)/n;
b=A*u;
%%%%%%
M=diag(1./diag(A));%ichol(A);%
% M=inv(M'*M);
A=M*A;
b=M*b;
K=4*length(b);
r=b-A*x;
z=A'*r;
P(:,1)=z;
resnorm=zeros(1,K);
resnorm(1)=norm(r);
s=1;
k=2;
S=zeros(1,K);
S(1)=1;
B=r;
for i=1:s-1
    P(:,i+1)=A'*P(:,i);
end
tic
while(S(k)<K)
      W=A*P;
    alfa=(W'*W)\(W'*r);
%     s=1+floor(abs(log(norm(alfa))));
    s=1+floor(sqrt(S(k)));
    x=x+P*alfa;
    r=r-W*alfa;
%     temp=B;
    z=A'*r;
    B(:,1)=z;
    for i=2:s
    B(:,i)=A'*B(:,i-1);
    end
     beta=(W'*W)\(W'*B);
    P=B+P*beta;
    resnorm(k)=norm(r);
    S(k+1)=S(k)+s;
    k=k+1;
       %%%%%%%%%%%%%
    lambda=1;
E=0.001*(x*b');
d=1/k;
w=r;
A=lambda*A+E*(w*w');
b=lambda*b+E*(d*w);
    %%%%%%%%%%%%%
end
toc
%  N=1:K;
 jndex=1;
 for j=1:K
     if S(j)==0
         jndex=j;
         break
     end
 end
 jndex=jndex-1;
 S=S(1:end-jndex);
 resnorm=resnorm(1:end-jndex);
%  S1=size(S);
%  S=1:S1(2);
%  S=S*(K/S1(2));
resnorm=log10(resnorm);
plot(S,resnorm,'ro-');
xlabel('iteration')
ylabel('log(||r||)')
legend('vs-CGNR','vs-CGNE');
% legend('eps=0.1','eps=0.01','eps=0.001');
%%%%%%%%%%%%%%%%%%%%%%
% plot(v,x,'bo-');
% legend('Exact','CGNE','vs-CGNE');
% xlabel('i')
% ylabel('x(i)')
 hold on
 end
