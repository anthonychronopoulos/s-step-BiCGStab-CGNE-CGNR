function [x,resnorm]= vsstepcg(A,b,x)
warning('off');
clc
clear r;
% M=diag(1./diag(A));%ichol(A);%
% % M=inv(M'*M);
% A=M*A;
% b=M*b;
K=length(b);
r=b-A*x;
z=A'*r;
P(:,1)=z;
resnorm=zeros(1,K);
s=1;
k=1;
S=zeros(1,K);
S(1)=1;
B=r;
tic
for i=1:s-1
    P(:,i+1)=A'*P(:,i);
end
while(S(k)<K)
      W=A*P;
    alfa=(W'*W)\(W'*r);
%     s=1+floor(abs(log(norm(alfa))));
%     s=1+floor(log(S(k)));
    x=x+P*alfa;
    r=r-W*alfa;
    temp=B;
    z=A'*r;
    B(:,1)=z;
    for i=2:s
    B(:,i)=A'*B(:,i-1);
    end
     beta=(W'*W)\(W'*B);
    P=B+P*beta;
    resnorm(k)=norm(r);
    S(k+1)=S(k)+s;
    k=k+1;
end
toc
%  N=1:K;
 jndex=1;
 for j=1:K
     if S(j)==0
         jndex=j;
         break
     end
 end
 jndex=jndex-1;
 S=S(1:end-jndex);
 resnorm=resnorm(1:end-jndex);
 norm(b-A*x)
resnorm=log10(resnorm);
plot(S,resnorm,'ko-');
legend('CGNE','vs-CGNE');
xlim([0,K]);
xlabel('iteration')
ylabel('log(||r||)')
 hold on
 end
