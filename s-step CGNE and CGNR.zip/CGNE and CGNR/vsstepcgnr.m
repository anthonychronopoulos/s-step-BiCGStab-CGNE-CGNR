function [x,resnorm]= vsstepcgnr(A,x,b)
warning('off');
clc
clear r;
%%%%%%%%%%%%% control problem%%
% n=200;
% t=0:1:201;
% y=zeros(n+2,1);
% x=exp(-t);
% b=zeros(n,1);
% A=zeros(n,n+2);
% eps=1;
% omega=1;
% dt=2*pi/128;
% kesi=1-eps*omega*dt;
% gamma=1+eps*omega*dt;
%  H=0.5;
%  L=1;
% v0=0;
%  y(1)=0;
%  y(2)=y(1)+v0*dt;
% for i=1:n
%     A(i,i)=kesi/gamma;
%     A(i,i+1)=-2/gamma;
%     A(i,i+2)=1;
%     b(i)=-dt^2/gamma*omega^2*x(i);
% end  
%   x=y;
% % M=diag(1./diag(A));%ichol(A);%
% % M=inv(M'*M);
% % A=M*A;
% % b=M*b;
K=length(b);
r=b-A*x;
z=A'*r;
P(:,1)=z;
resnorm=zeros(1,K);
resnorm(1)=norm(r);
s=1;
k=1;
S=zeros(1,K);
S(1)=1;
B=z;
for i=1:s-1
    P(:,i+1)=A'*P(:,i);
end
tic
while(S(k)<K)
    W=A*P;
    alfa=(W'*W)\(B'*z);
%     s=1+floor(abs(log(norm(alfa))));
%    s=1+floor(sqrt(S(k)));
    x=x+P*alfa;
    r=r-W*alfa;
    temp=B;
    z=A'*r;
    B(:,1)=z;
    for i=1:s-1
    B(:,i+1)=A'*B(:,i);
    end
     beta=(temp'*temp)\(temp'*B);
    P=B+P*beta;
    resnorm(k)=norm(r);
    S(k+1)=S(k)+s;
    k=k+1;
end
toc
%  N=1:K;
 jndex=1;
 for j=1:K
     if S(j)==0
         jndex=j;
         break
     end
 end
 jndex=jndex-1;
 S=S(1:end-jndex);
 resnorm=resnorm(1:end-jndex);
norm(b-A*x)
resnorm=log10(resnorm);
plot(S,resnorm,'ko-');
legend('CGNR','vs-CGNR');
% legend('s-CGNR(s=3)','s-CGNR(s=4)','s-CGNR(s=5)','vs-CGNR');

xlim([0,K]);
xlabel('iteration')
ylabel('log(||r||)')
 hold on
 end
