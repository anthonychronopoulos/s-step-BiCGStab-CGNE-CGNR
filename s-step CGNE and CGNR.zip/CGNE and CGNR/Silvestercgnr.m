function [X,resnorm]= Silvestercgnr()
warning('off');
clc
clear r;
n=30;
X=zeros(n,n);
A=-triu(rand(n,n),1)*1i+diag(1.75+diag(rand(n)));
B=tril(rand(n,n),1)+diag(1.5+diag(rand(n)))*1i;
C=triu(rand(n,n),1)+diag(1.5+diag(rand(n)))*1i;
D=tril(rand(n,n),1)*1i+diag(2+diag(rand(n)));
M=A*ones(n,n)*B+C*ones(n,n)*D;
K=4999;
R=M-A*X*B-C*X*D;
W=(A)'*R*(B)'+(C)'*R*(D)';
P=W;
gamma=norm(W,'fro')^2;
resnorm=zeros(1,K);
resnorm(1)=norm(R,'fro');
k=1;
tic
while(k<=K)
    Q=A*P*B+C*P*D;
    delta=gamma/norm(Q,'fro')^2;
    X=X+P*delta;
    R=R-Q*delta;
    resnorm(k+1)=norm(R,'fro');
   W=((A)'*R*(B)'+(C)'*R*(D)');
%     Z=Z-W*gamma;
    gamma1=gamma;
     gamma=norm(W,'fro')^2;
     lambda=gamma/gamma1;
    P=W+P*lambda;
    k=k+1;
end
toc
S=1:length(resnorm);
resnorm=log10(resnorm);
plot(S,resnorm,'r*-');
xlabel('iteration')
ylabel('log(||r||)')
 hold on
 end
