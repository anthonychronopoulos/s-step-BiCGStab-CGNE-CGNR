%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% MAIN PROGRAM FOR s-step Conjugate Gradient method %%
%%%% Programs� Authors : A. T. Chronopoulos and H. S. Kaveh                %%
%% s-step Conjugate gradient (CG)Krylov methods functions to solve %%
%% sparse linear systems A x=b, with A symmetric positive definite %%           %% Functions called: mmread, sCGalg21vmm2s, sPrCGalg21vmm2s, pcg   %%
%% Matrix Data-files from sparse matrices (MM)-format from collection %%
%% https://www.cise.ufl.edu/research/sparse/matrices/list_by_id.html  %%      %% mesh3e1.mtx    %%
%% rhs b is created to have solution vector of all entries=1  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% s-step CG  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% �NO Precond sCG� algorithm is from paper:
%%% A. T. Chronopoulos, C. W. Gear, s-step iterative methods for %%%symmetric linear systems,  Journal of Computational and Applied %%%Mathematics, 25(2),  153-168, 1989.  
%%%  �Precond sCG�algorithm  is from paper:
%%% A. T. Chronopoulos, C. W. Gear, On the efficient implementation of %%%preconditioned s-step conjugate %%% gradient methods on %%%multiprocessors with memory hierarch, Parallel Computing, 11(1), 37-%%%53, 1989.  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
warning('off'); 
A=mmread('mesh3e1.mtx'); 
s=5;
tol=1.d-9;
n=size(A,1);
K=1000; % number of iterations.
% create rhs b, so that x1 is the solution
x1=ones(n,1); % known solution
b =A*x1; % right hand side (rhs)
x=zeros(n,1);
% Matlab, incomplete Cholesky factorization (ICF) of A: L = ichol(A);
% https://www.mathworks.com/help/matlab/ref/ichol.html 
%i.e. A=L*L�
%% transform to ICF precond  li. Sy. A*x=b 
%%  ICF symmetric precond li.Sys. Ax = b <=>  (I)inv(L)*A*inv(L')* y= 
%% inv(L)*b AND %%  L'* x =y
%% So: A~L*L', inv(A) ~ inv(L*L') ~ inv(L')*inv(L)
%% too costly to compute matrix inverses for inv(L') and inv(L) 
%% Instead , We always Compute: L'\x and  L\x
%% (ICF) prec A ; For Av=A*v, We do 
%%(I)(1) vtmp= L'\v (2) A*vtmp (3) Av= L\v 
%% (II) (4) After MAIN loop ends: solution of Ax=b is found: L'\x

  
%%%:CALL s-step CG (sCG) and VERIFY TRUE error/residual norm

%%%%%%%%%%%%%%% NO PRECOND S-step CG %%%%%%%%%%%%%%%%%%%
   
tic,x_sCG21vmm2s=sCGalg21vmm2s(A,b,s,x,K,tol); 
disp('true error x_sCG21vmm2s =') 
disp(norm(x_sCG21vmm2s -x1))
disp('residual error sCG21vmm2s=')
disp(norm(b-A*x_sCG21vmm2s))               
         
%%%%%%%%%%%%%%% END NO PRECOND S-step CG %%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%% PRECOND S-step CG %%%%%%%%%%%%%%%%%%%


tic,x_sPrCG21vmm2s=sPrCGalg21vmm2s(A,b,s,x,K,tol); 
disp('true error x_sPrCG21vmm2s =') 
disp(norm(x_sPrCG21vmm2s -x1))
disp('residual error sPrCG21vmm2s=')
disp(norm(b-A*x_sPrCG21vmm2s))   
          
%%%%%%%%%%%%%%% END  PRECOND S-step CG %%%%%%%%%%%%%%%%%%%



%% our Matlab/OCTAVE programmed CG%% 
%%%%%%%%%% Not Preconditioned CG method%%%%%%%%%

tic,x_CGalg21=CGalg21(A,b,x,K,tol); 

disp('true error x_CG21=') 
disp(norm(x_CGalg21-x1))
disp('residual error CGalg21=')
disp(norm(b-A*x_CGalg21)) 

%%%%%%%%%% preconditioned CG method%%%%%%%%%
tic,x_PrCG21=PrCGalg21(A,b,x,K,tol); 

disp('true error x_PrCG21=') 
disp(norm(x_PrCG21-x1))
disp('residual error PrCGalg21=')
disp(norm(b-A*x_PrCG21)) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
%%%%%%%%%%Mathworks MATLAB CG methods%%%%%%%%%
%%%  https://www.mathworks.com/help/matlab/ref/pcg.html

%%%%%%%%%% Not Precondtioned CG method%%%%%%%%% 

% PLEASE CALL mathworks  matlab CGalgm 
%M=speye(n); 
% create "identity" matrix as preconditioner example
% x = pcg(A,b,tol,maxit,M) computes x by CG of matlab,
%x =pcg(A,b,tol,maxit,M1,M2,x0) specifies the initial guess. 
% If x0 is empty ,then pcg uses the default, an all-zero vector.
% L = ichol(A) performs the incomplete Cholesky factorization of A with %zero-fill. A must be a sparse square matrix. Then M1=L and M2=L';


maxit=K; 

%%%%%%%%%% Not Preconditioned CG method%%%%%%%%% 


L= speye(n); 
tic,x_matlab=pcg(A,b,tol,maxit,L,L',x);toc
disp('true error Matlab cg=') 
disp(norm(x_matlab-x1))
disp('residual error Matlab pcg=')
 disp(norm(b-A*x_matlab))

%%%%%%%%%% ICF Preconditioned CG method%%%%%%%%% 

L=ichol(A);

tic,x_matlab=pcg(A,b,tol,maxit,L,L',x);toc
disp('true error Matlab precond cg=') 
disp(norm(x_matlab-x1))
disp('residual error Matlab pcg=')
 disp(norm(b-A*x_matlab))


