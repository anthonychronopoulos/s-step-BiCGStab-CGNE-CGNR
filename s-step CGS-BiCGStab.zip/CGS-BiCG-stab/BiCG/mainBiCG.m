warning('off');
clc
clear r;
%%%%%%%%%%%%%intializations%%%%%%%%%%
% n=10;
% A=zeros(n,n);
% A(1,1)=2;
% A(2,1)=-1;
% A(n-1,n)=-1;
% A(n,n)=2;
% for i=2:n-1
%     A(i,i)=2;
%     A(i-1,i)=-1;
%     A(i+1,i)=-1;
% end
% sigma=sqrt(3);
% A=A^2-sigma*eye(n,n);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 A=mmread('Chem97ZtZ.mtx');
 n=size(A,2);
x=zeros(n,1);
x1=ones(n,1);
b=A*x1;
K=999;
 tol=10^(-16);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
tic;[x_BiCG,resBiCG]=BiCG(A,b,x,K,tol);
disp('true error BiCG=') 
disp(norm(x_BiCG-x1))
disp('residual error BiCG=')
disp(resBiCG)
%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCG,ressBiCG]=sBiCG(A,b,x,K,tol);
disp('true error stikhBiCG=') 
disp(norm(x_sBiCG-x1))
disp('residual error stikhBiCG=')
disp(ressBiCG)
%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCG,ressBiCG]=sexpBiCG(A,b,x,K,tol);
disp('true error sexphBiCG=') 
disp(norm(x_sBiCG-x1))
disp('residual error sexphBiCG=')
disp(ressBiCG)
%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCG,ressBiCG]=shypBiCG(A,b,x,K,tol);
disp('true error shyphBiCG=') 
disp(norm(x_sBiCG-x1))
disp('residual error shypBiCG=')
disp(ressBiCG)
%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCG,ressBiCG]=ssignBiCG(A,b,x,K,tol);
disp('true error ssignhBiCG=') 
disp(norm(x_sBiCG-x1))
disp('residual error ssignBiCG=')
disp(ressBiCG)
%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCG,ressBiCG]=slogBiCG(A,b,x,K,tol);
disp('true error sloghBiCG=') 
disp(norm(x_sBiCG-x1))
disp('residual error slogBiCG=')
disp(ressBiCG)
%%%%%%%%%%%%%%%%%%%%%
