warning('off');
clc
clear r;
%%%%%%%%%%%%%intializations%%%%%%%%%%
% n=10;
% A=zeros(n,n);
% A(1,1)=2;
% A(2,1)=-1;
% A(n-1,n)=-1;
% A(n,n)=2;
% for i=2:n-1
%     A(i,i)=2;
%     A(i-1,i)=-1;
%     A(i+1,i)=-1;
% end
% sigma=sqrt(3);
% A=A^2-sigma*eye(n,n);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A=mmread('mesh1em6.mtx');
%  A=tril(rand(n1,n1),1)*1i+diag(1.25+diag(rand(n1)));
%  A =triu(rand(n1, n1), 1)*1i+diag(1+ diag(rand(n1)));
%  A =tril(rand(n1, n1), 1)*1i + diag(1.5 + diag(rand(n1)));
% A=tril(rand(n1,n1),1)*1i + diag(2 + diag(rand(n1)));
% A=A+1i*A;
n=size(A,1);
x=zeros(n,1);
x1=ones(n,1);
b=A*x1;
K=199;
tol=10^(-1000);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_GMRES,resGMRES]=GMRES(A,b,x,K,tol);
disp('true error GMRES=') 
disp(norm(x_GMRES-x1))
disp('residual error GMRES=')
disp(resGMRES)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sexpBiCG,ressBiCG]=sexpBiCG(A,b,x,K,tol);
disp('true error sBiCG=') 
disp(norm(x_sexpBiCG-x1))
disp('residual error sBiCG=')
disp(ressBiCG)
%%%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sexpBiCGstab,ressBiCGstab]=sexpBiCGstab(A,b,x,K,tol);
disp('true error sBiCGstab=') 
disp(norm(x_sexpBiCGstab-x1))
disp('residual error sBiCGstab=')
disp(ressBiCGstab)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sexpCGS,ressCGS]=vsexpCGS(A,b,x,K,tol);
disp('true error sCGS=') 
disp(norm(x_sexpCGS-x1))
disp('residual error sCGS=')
disp(ressCGS)