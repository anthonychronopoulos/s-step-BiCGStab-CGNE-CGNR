function [x_GMRES,resGMRES]=GMRES(A,b,x,K,tol)
% warning('off');
% clc
% clear r;
n=length(b);
x0=x;
r=A*x-b;
beta=norm(r);
resnorm(1)=beta;
v=r/beta;
ro=beta;
k=0;
V=v;
while(k<=K)
    k=k+1;
    S=zeros(n,1);
    Av=A*V(:,k);
 for j=1:k
     H(j,k)=Av'*V(:,j);
     S=S+H(j,k)*V(:,j);
 end
 vhat=Av-S;
 H(k+1,k)=norm(vhat);
 V(:,k+1)=vhat/H(k+1,k);
 e=zeros(k+1,1);
 e(1)=1;
 y=H\(beta*e);
 x=x0-V(:,1:k)*y;
 resnorm(k)=norm(A*x-b);
% % %   resnorm(k)=norm(beta*e-H*y);
 if resnorm(k)<tol
     break
 end
end
toc
x_GMRES=x;
resGMRES=resnorm(end);
h=1:length(resnorm);
resnorm=log10(resnorm);
plot(h,resnorm,'b*-');
xlabel('iteration')
ylabel('log(||r||)')
 hold on
 end
