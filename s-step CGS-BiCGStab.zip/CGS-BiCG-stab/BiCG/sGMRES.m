function [x]= sGMRES()          
% function with output x , ro and input A,b,x initial vector
warning('off');                                               
clc          
clear  r;     
A=mmread('can24.mtx');
n=size(A,1);
x1=ones(n,1);
b=A*x1;
x=randn(n,1);
K=length(b);
x0=x;
%%%%%%%%%%%%%precondition%%%%%%
M=diag(1./diag(A));%ichol(A);
% M=inv(M'*M);
A=M*A;
b=M*b;
%%%%%%%%%%%%%%%%%%%%
r=A*x-b;
beta=norm(r);
ro(1)=beta;
V(:,1)=r/beta;
s=1;
 for k=1:s-1
       V(:,k+1)=A*V(:,k); 
        V(:,k+1)= V(:,k+1)/norm(V(:,k+1));
 end
 k=1;
 sk=s;
 S1=zeros(n,1);
 S2=S1;
tic   
while sk<=K
%     for j=1:k
       H=(V'*V)\(V'*A*V);
       S1=S1+V*H(:,1);
%     end
     v1=A*V(:,end)-S1;
     v1=v1/norm(v1);
     T=(V'*V)\(V'*A*v1);
      S2=S2+V*T;
      U(:,1)=v1;
%       s=1+floor(k/10);
      for i=2:s
      U(:,i)=A*U(:,i-1)-S2;
      U(:,i)=U(:,i)/norm(U(:,i));
      end
      e1=zeros(sk,1);
      e1(1)=1;
      y=H\(beta*e1);
      x=x0+V*y;
     sk=sk+s;
      k=k+1;
      r=b-A*x;%H*y-beta*e1;
      ro(k)=norm(r);
      V=[V U];
end  
toc
h=1:length(ro);  
ro=log10(ro);                                                       
plot(h,ro,'g-H') 
xlabel('iteration')
ylabel('log(||r||)')
legend('sGMRES') 
hold on                                                               
end                