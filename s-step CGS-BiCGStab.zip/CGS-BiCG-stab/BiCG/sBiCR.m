function [x,res]= sBiCR()              
% function with output x , ro and input A,b,x initial vector
warning('off');                                               
clc          
clear  r;     
A=mmread('gr_30_30.mtx');
n=size(A,1);
x1=ones(n,1);
b=A*x1;
%%%%%%%%%%%%%precondition%%%%%%
% M=diag(1./diag(A));%ichol(A);
% % M=inv(M'*M);
% A=M*A;
% b=M*b;
%%%%%%%%%%%%%%%%%%%%
K=500;%length(b);
x=zeros(n,1);
r=A*x-b;
rhat=r;
R=r;
P=R;
Rhat=R;
Phat=Rhat;
ro=zeros(K+1,1);                         
ro(1)=norm(r);
s=1;
sk=s;
i=1;
tic   
while sk<=K
   W=A*P;
   W1=A'*Phat;
   sigma=W1'*W;
   alpha=sigma\(W1'*r);
   alpha=(norm(alpha)^2/(1+s*norm(alpha)^2))*alpha;
   x=x-P*alpha;
   r=r-W*alpha;
%    r1=b-A*x;
   rhat=rhat-W1*alpha;
   Rhat(:,1)=rhat;  
    s=2*(1+floor(log10(sk)));
   R(:,1)=r;
   Rhat(:,1)=rhat;
for j=2:s
    Rhat(:,j)=A'*Rhat(:,j-1);%-(Rhat(:,j-1)'*A*Rhat(:,j-1))*(Rhat(:,j-1));
    R(:,j)=A*R(:,j-1);%-(R(:,j-1)'*A*R(:,j-1))*(R(:,j-1));
end
beta=sigma\(W1'*R);
beta=(norm(beta)^2/(1+s^2*norm(beta)^2))*beta;
P=R-P*beta;
Phat=Rhat-Phat*beta;
ro(i+1)=norm(r);
sk=sk+s;
    i=i+1;
end  
toc
res=norm(b-A*x);
h=1:length(ro);  
ro=log10(ro);                                                       
plot(h,ro,'g-*') 
xlabel('iteration')
ylabel('log(||r||)')
legend('sBiCG') 
hold on                                                               
end                