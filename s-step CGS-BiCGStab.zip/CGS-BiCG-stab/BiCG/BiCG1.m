function [x,res]= BiCG1(A,b,x,K)            
% function with output x , ro and input A,b,x initial vector
% warning('off');                                               
% clc          
% clear  r;     
% A=mmread('662_bus.mtx');
% n=size(A,1);
% x1=ones(n,1);
% b=A*x1;
% %%%%%%%%%%%%%precondition%%%%%%
% M=diag(1./diag(A));%ichol(A);
% % M=inv(M'*M);
% A=M*A;
% b=M*b;
%%%%%%%%%%%%%%%%%%%%
% K=10*length(b);
% x=zeros(n,1);
r=A*x-b;
rhat=r;
R=r;
P=R;
Rhat=R;
Phat=Rhat;
ro=zeros(K+1,1);                         
ro(1)=norm(r);
sk=1;
i=1;
% tol=1;
s=1;
% tic   
while sk<=K
   W=A*P;
   W1=A'*Phat;
   sigma=Phat'*W;
   %%%%%%%%%%%%planer
%    lambda=P'*W;
%    tol=(tol/s)^2;
% %    tol=exp(-tol)*tol;
% %    tol=(tol^2/(tol^2+s^2))*tol;
%    if norm(sigma)<tol*norm(lambda)
%        sigma=lambda;
%        Phat=P;
%    end
   %%%%%%%%%%%%%%%
   alpha=sigma\(Phat'*r);
   x=x-P*alpha;
   r=r-W*alpha;
   rhat=rhat-W1*alpha;
   Rhat(:,1)=rhat;  
   R=r;
   Rhat=rhat;
beta=sigma\(W1'*R);
P=R-P*beta;
Phat=Rhat-Phat*beta;
ro(i+1)=norm(r);
sk=sk+s;
    i=i+1;
end  
toc
res=ro(i-1);
h=1:length(ro);  
ro=log10(ro);                                                       
plot(h,ro,'y-*') 
xlabel('iteration')
ylabel('log(||r||)')
legend('BiCG') 
hold on                                                               
end                