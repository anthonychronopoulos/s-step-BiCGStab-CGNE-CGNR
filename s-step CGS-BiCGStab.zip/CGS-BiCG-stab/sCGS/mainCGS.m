warning('off');
clc
clear r;
%%%%%%%%%%%%%intializations%%%%%%%%
% n=100;
% A=zeros(n,n);
% A(1,1)=2;
% A(2,1)=-1;
% A(n-1,n)=-1;
% A(n,n)=2;
% for i=2:n-1
%     A(i,i)=2;
%     A(i-1,i)=-1;
%     A(i+1,i)=-1;
% end
% sigma=-sqrt(3);
% A=A'*A-sigma*eye(n,n);
%%%%%%%%%%%%%%%%%%%%%%%%%%
A=mmread('mesh2e1.mtx');
n=size(A,2);
x=zeros(n,1);
x1=ones(n,1);
b=A*x1;
K=999;
tol=10^(-16);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%
tic;[x_CGS,resCGS]=sCGS(A,b,x,K,tol);
disp('true error CGS=') 
disp(norm(x_CGS-x1))
disp('residual error CGS=')
disp(resCGS)
%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sstepCGS,ressstepCGS]=sstepCGS(A,b,x,K,tol);
disp('true error vstikhCGS=') 
disp(norm(x_sstepCGS-x1))
disp('residual error vstikhCGS=')
disp(ressstepCGS) 
%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sstepCGS,ressstepCGS]=vsexpCGS(A,b,x,K,tol);
disp('true error vsexpCGS=') 
disp(norm(x_sstepCGS-x1))
disp('residual error vsexpCGS=')
disp(ressstepCGS) 
%%%%%%%%%%%%%%%%%%%%%
tic;[x_sstepCGS,ressstepCGS]=vshypCGS(A,b,x,K,tol);
disp('true error vshypCGS=') 
disp(norm(x_sstepCGS-x1))
disp('residual error vshypCGS=')
disp(ressstepCGS) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sstepCGS,ressstepCGS]=vssignCGS(A,b,x,K,tol);
disp('true error vssignCGS=') 
disp(norm(x_sstepCGS-x1))
disp('residual error vssignCGS=')
disp(ressstepCGS) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;[x_sstepCGS,ressstepCGS]=vslogCGS(A,b,x,K,tol);
disp('true error vslogCGS=') 
disp(norm(x_sstepCGS-x1))
disp('residual error vslogCGS=')
disp(ressstepCGS) 