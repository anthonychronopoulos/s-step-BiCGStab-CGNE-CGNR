function [x,ressstepCGS]= vssignCGS(A,b,x,K,tol)             
% function with output x , ro and input A,b,x initial vector
warning('off');                                               
% clc          
% clear  r;     
%%%%%%%%%%%%%%%%%%%%%%%%%%
% A=mmread('gr_30_30.mtx');
% n=size(A,2);
% x=zeros(n,1);
% x1=ones(n,1);
% b=A*x1;
% K=n;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M=diag(1./diag(A));%ichol(A);
% %M=inv(M'*M);
% A=M*A;
% b=M*b;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
r=A*x-b;
r1=A'*r;
R1=r1;
R=r;
P=R;
U=P;
V=A*U;
% ro=zeros(K+1,1);                         
ro(1)=norm(r);
s=1;
sk=1;
i=0;
% tic   
while sk<=K
    i=i+1;
   sigma=R1'*V;
   Ro=R1'*R;
   alpha=sigma\Ro;
%     na=norm(alpha);
%    ka=(na^2/(1+s*na^2));
%    ka=exp(-s/na);
%     ka=(1-tanh(s/na));
%  ka=0.5*(sign(s/na-1/s)+1);
% ka=((log(sqrt((s/na)+1)+s/na))/(sinh(s/na)));
% alpha=ka*alpha;
   Q=U-V*(alpha);
   x=x-(U+Q)*alpha(:,1);
   r=r-A*(U+Q)*alpha(:,1);
   Rohat=R1'*R;
   R2=R1;
   R1(:,1)=r1;  
   R(:,1)=r;
   s=2*(2+floor(log10(sk)));
for j=2:s
    R1(:,j)=A'*R1(:,j-1);
    R(:,j)=A*R(:,j-1);
end
Ro=R2'*R;
beta=Rohat\Ro;
nb=norm(beta);
% kb=(nb^2/(1+s^2*nb^2));
%    kb=exp(-s^2*nb^2);
% kb=(1-tanh(s^2*nb^2));
 kb=0.5*(sign(s^2/nb^2-nb)+1);
% kb=((log(sqrt(nb+1)+nb))/(sinh(nb)));
beta=kb*beta;
U=R+Q*beta;
P=U+(Q+P)*beta;
V=A*P;
ro(i+1)=norm(r);
if ro(i+1)<tol
    break
end
sk=sk+s;
end  
toc
ressstepCGS=ro(end);
h=1:length(ro);  
ro=log10(ro);                                                       
plot(h,ro,'c-^') 
xlabel('iteration')
ylabel('log(||r||)')
legend('CGS','vsCGS') 
hold on                                                               
end                