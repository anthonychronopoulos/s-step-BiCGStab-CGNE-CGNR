function [x,resCGS]= sCGS(A,b,x,K,tol)              
% function with output x , ro and input A,b,x initial vector
warning('off');                                               
% clc          
% clear  r;     
%%%%%%%%%%%%%%%%%%%%%%%%%%
% A=mmread('gr_30_30.mtx');
% n=size(A,2);
% x=zeros(n,1);
% x1=ones(n,1);
% b=A*x1;
% K=100;
% tol=0.5;%10^(-16);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M=diag(1./diag(A));%ichol(A);
% %M=inv(M'*M);
% A=M*A;
% b=M*b;
% K=length(b);
r=A*x-b;
rhat=A'*r;
R=r;
P=R;
U=r;
V=A*P;
Rhat=rhat;
% ro=zeros(K+1,1);                         
ro(1)=norm(r);
Ro=r'*rhat;
s=1;
sk=0;
i=0;
% tic   
while sk<=K
    i=i+1;
   sigma=Rhat'*V;
   alpha=sigma\Ro';
%   na=norm(alpha);
%     alpha=(na/(1+na))*alpha;
%       alpha=exp(-na)*alpha;
%       alpha=(1-tanh(na))*alpha;
%   alpha=0.5*(sign(1/na-1)+1)*alpha;
% alpha=((log(sqrt(na^2+1)+na))/(sinh(na)))*alpha;
   Q=U-V*(alpha);
   x=x-(U+Q)*alpha;
   r=r-A*(U+Q)*alpha;
 rhat=A'*r;
   Rhat(:,1)=rhat;  
   R(:,1)=r;
Rohat=Ro;
Ro=rhat'*R;
beta=Rohat\Ro;
nb=norm(beta);
kb=(nb^2/(1+nb^2));
%    kb=exp(-nb);
% kb=(1-tanh(nb));
%  kb=0.5*(sign(1/nb-1)+1);
% kb=((log(sqrt(nb^2+1)+nb))/(sinh(nb)));
beta=kb*beta;
U=R+Q*beta;
P=U+(Q+P)*beta;
V=A*P;
ro(i+1)=norm(r);
if ro(i+1)<tol
    break
end
sk=sk+s;
end  
toc
resCGS=ro(end);
h=1:length(ro);  
ro=log10(ro);                                                       
plot(h,ro) 
xlabel('iteration')
ylabel('log(||r||)')
legend('sCGS') 
hold on                                                               
end                