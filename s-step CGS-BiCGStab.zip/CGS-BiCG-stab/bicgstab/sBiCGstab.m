function [x,res]= sBiCGstab(A,b,x,K,tol)         
% function with output x , ro and input A,b,x initial vector
% warning('off');                                               
% clc          
% clear  r;     
% A=mmread('pde225.mtx');
% n=size(A,1);
% x=zeros(n,1);
% x1=ones(n,1);
% b=A*x1;
%%%%%%%%%%%%%precondition%%%%%%
% M=diag(1./diag(A));%ichol(A);
% % M=inv(M'*M);
% A=M*A;
% b=M*b;
%%%%%%%%%%%%%%%%%%%%
% K=length(b);
r=b-A*x;
rhat=r;
R=r;
P=R;
Rhat=R;
% ro=zeros(K,1);                         
ro(1)=norm(r);
s=1;
sk=s;
i=1;
tic   
while sk<=K
    W=A*P;
   sigma=W'*W;
   alpha=sigma\(P'*R);
   na=norm(alpha);
   alpha=(na/(1+s*na^2))*alpha;
%    alpha=exp(-s^2*na)*alpha;
%       alpha=(1-tanh(s^2*na))*alpha;
%  alpha=(sign(s^2/na-na)+1)*alpha;
% alpha=((log(sqrt(na+1)+na))/(sinh(na)))*alpha;
   T=R-W*alpha;
   kesi=sigma\(W'*T);
   x=x+P*alpha(:,1)+T*kesi(:,1);
   r=r-W*alpha(:,1)-A*T*kesi(:,1);
%    Rhat(:,1)=rhat;  
   s=2*(1+floor(log10(sk)));
   R1=R;
   R(:,1)=r;
   Rhat(:,1)=rhat;
for j=2:s
    Rhat(:,j)=A'*Rhat(:,j-1);
    R(:,j)=A*R(:,j-1);
end
beta=sigma\(R1'*R);
nb=norm(beta);
beta=(nb^2/(1+s^2*nb^2))*beta;
%    beta=exp(-s^2*nb^2)*beta;
% beta=(1-tanh(s^2*nb^2))*beta;
%  beta=(sign(s^2/nb-nb)+1)*beta;
% beta=((log(sqrt(nb+1)+nb))/(sinh(nb)))*beta;
 P=R+(P-W*kesi)*beta;
ro(i+1)=norm(r);
sk=sk+s;
    i=i+1;
    if ro(i)<tol
        break
    end
end  
toc
res=ro(end);
h=1:length(ro);  
ro=log10(ro);                                                       
plot(h,ro,'c-^') 
xlabel('iteration')
ylabel('log(||r||)')
legend('BiCGstab','vsBiCGstab') 
hold on                                                               
end                