warning('off');
clc
clear r;
%%%%%%%%%%%%%intializations%%%%%%%%%%
% n=2;
% A=zeros(n,n);
% A(1,1)=2;
% A(2,1)=-1;
% A(n-1,n)=-1;
% A(n,n)=2;
% for i=2:n-1
%     A(i,i)=2;
%     A(i-1,i)=-1;
%     A(i+1,i)=-1;
% end
% sigma=sqrt(1);
% A=A^2-sigma*eye(n,n);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 A=mmread('swang1.mtx');
 n=size(A,2);
x=zeros(n,1);
x1=ones(n,1);
b=A*x1;
K=999;
tol=10^(-16);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
tic;[x_BiCGstab,resBiCGstab]=BiCGstab(A,b,x,K,tol);
disp('true error BiCGstab=') 
disp(norm(x_BiCGstab-x1))
disp('residual error BiCGstab=')
disp(resBiCGstab)
%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCGstab,ressBiCGstab]=sBiCGstab(A,b,x,K,tol);
disp('true error vstikhBiCGstab=') 
disp(norm(x_sBiCGstab-x1))
disp('residual error vstikhBiCGstab=')
disp(ressBiCGstab)
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCGstab,ressBiCGstab]=sexpBiCGstab(A,b,x,K,tol);
disp('true error vsexpBiCGstab=') 
disp(norm(x_sBiCGstab-x1))
disp('residual error vsexpBiCGstab=')
disp(ressBiCGstab)
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCGstab,ressBiCGstab]=shypBiCGstab(A,b,x,K,tol);
disp('true error vshypBiCGstab=') 
disp(norm(x_sBiCGstab-x1))
disp('residual error vshypBiCGstab=')
disp(ressBiCGstab)
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCGstab,ressBiCGstab]=ssignBiCGstab(A,b,x,K,tol);
disp('true error vssignBiCGstab=') 
disp(norm(x_sBiCGstab-x1))
disp('residual error vssignBiCGstab=')
disp(ressBiCGstab)
%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%
tic;[x_sBiCGstab,ressBiCGstab]=slogBiCGstab(A,b,x,K,tol);
disp('true error vslogBiCGstab=') 
disp(norm(x_sBiCGstab-x1))
disp('residual error vslogBiCGstab=')
disp(ressBiCGstab)
%%%%%%%%%%%%%%%%%%%%%%%
