function [x,res]= sHexpBiCGstab(A,b,x,K,tol)          
% function with output x , ro and input A,b,x initial vector
% warning('off');                                               
% clc          
% clear  r;     
% A=mmread('gr_30_30.mtx');
% n=size(A,1);
% x=zeros(n,1);
% x1=ones(n,1);
% b=A*x1;
%%%%%%%%%%%%%precondition%%%%%%
% M=diag(1./diag(A));%ichol(A);
% % M=inv(M'*M);
% A=M*A;
% b=M*b;
%%%%%%%%%%%%%%%%%%%%
n=length(b);
r=b-A*x;
R=r;
P=A*R-(r'*A*R)*r;
ro=zeros(K,1);                         
ro(1)=norm(r);
W=A*P;
s=1;
beta=0;
Omega=zeros(n,1);
U=zeros(n,1);
sk=s;
i=1;
tic   
while sk<=K
   sigma=W'*W;
   alpha=sigma\(P'*R);
   na=norm(alpha);
   if i==1
   alpha=(na^2/(1+s^2*na^2))*alpha;
   else
   alpha=exp(-s^2*na)*alpha;
%       alpha=(1-tanh(s^2*na))*alpha;
%  alpha=(sign(s^2/na-na)+1)*alpha;
% alpha=((log(sqrt(na+1)+na))/(sinh(na)))*alpha;
   end
   T=R-W*alpha;
   Y=T-R-Omega*alpha+A*P*alpha;
   if mod(i,2)==1
   YY=Y'*Y;
   WY=W'*Y;
   YW=Y'*W;
   WT=W'*T;
   YT=Y'*T;
       kesi=((sigma)*(YY)-(YW)*(WY))\((YY)*(WT)-(YT)*(WY));
       eta=((sigma)*(YY)-(YW)*(WY))\((sigma)*(YT)-(YW)*(WT));
       s=2;%+floor(i/200);%+floor((log10(sk)));
   else
        kesi=sigma\(W'*T);
   eta=zeros(size(kesi));
   s=1;
   end
   U=W*kesi+(T-R+U*beta)*eta;
   Z=R*kesi-U*alpha;
    x=x+P*alpha(:,1)+Z(:,1);
   r=r-W*alpha(:,1)-A*Z(:,1);
%    Rhat(:,1)=rhat;  
%    s=1+floor(i/150);
   R1=R;
   R(:,1)=r;
%    Rhat(:,1)=rhat;
for j=2:s
%     Rhat(:,j)=A'*Rhat(:,j-1);
    R(:,j)=A*R(:,j-1);
end
beta=sigma\(R1'*R);
nb=norm(beta);
% beta=(nb^2/(1+s^2*nb^2))*beta;
   beta=exp(-s^2*nb)*beta;
% beta=(1-tanh(s^2*nb^2))*beta;
%  beta=(sign(s^2/nb-nb)+1)*beta;
% beta=((log(sqrt(nb+1)+nb))/(sinh(nb)))*beta;
 P=R+(P-U)*beta;
  W=A*P;
  T=R-W;%*norm(alpha);
  Omega=A*T+W*nb;
ro(i+1)=norm(r);
sk=sk+s;
    i=i+1;
    if ro(i)<tol
        break
    end
end  
toc
res=ro(i);
h=1:length(ro);  
ro=log10(ro);                                                       
plot(h,ro,'k-o') 
xlabel('iteration')
ylabel('log(||r||)')
% legend('BiCGstab','vsBiCGstab','HybridBiCGstab','vsHybridBiCGstab') 
hold on                                                               
end                